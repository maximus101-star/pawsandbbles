Strike a Chord — Chapter 2 Practice Lab

Files:
- index.html: completed home page
- template.html: reusable semantic HTML5 template

GitHub Pages upload:
1. Open the pawsandbbles GitHub repository.
2. Choose Add file > Upload files.
3. Drag the entire strike-a-chord folder (not just the files) into the upload area.
4. Commit changes.
5. Visit https://pawsandbbles.shop/strike-a-chord/ once DNS and HTTPS are working.

This is an implementation of the course's listed objectives; exact textbook lab directions were not available.
